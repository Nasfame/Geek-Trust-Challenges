family_tree = {
  "name": "Shah Family",
  "members": [
    [
      "King Shah",
      "Male",
      "root",
      ""
    ],
    [
      "Queen Anga",
      "Female",
      "root",
      "King Shah"
    ],
    [
      "Chit",
      "Male",
      "Queen Anga",
      ""
    ],
    [
      "Amba",
      "Female",
      "not family",
      "Chit"
    ],
    [
      "Ish",
      "Male",
      "Queen Anga",
      ""
    ],
    [
      "Vich",
      "Male",
      "Queen Anga",
      ""
    ],
    [
      "Lika",
      "Female",
      "not family",
      "Vich"
    ],
    [
      "Aras",
      "Male",
      "Queen Anga",
      ""
    ],
    [
      "Chitra",
      "Female",
      "not family",
      "Aras"
    ],
    [
      "Satya",
      "Female",
      "Queen Anga",
      ""
    ],
    [
      "Vyan",
      "Male",
      "not family",
      "Satya"
    ],
    [
      "Dritha",
      "Female",
      "Amba",
      ""
    ],
    [
      "Jaya",
      "Male",
      "not family",
      "Dritha"
    ],
    [
      "Tritha",
      "Female",
      "Amba",
      ""
    ],
    [
      "Vritha",
      "Male",
      "Amba",
      ""
    ],
    [
      "Vila",
      "Female",
      "Lika",
      ""
    ],
    [
      "Chika",
      "Female",
      "Lika",
      ""
    ],
    [
      "Arit",
      "Male",
      "not family",
      ""
    ],
    [
      "Jnki",
      "Female",
      "Chitra",
      "Arit"
    ],
    [
      "Ahit",
      "Male",
      "Chitra",
      ""
    ],
    [
      "Satvy",
      "Female",
      "not family",
      ""
    ],
    [
      "Asva",
      "Male",
      "Satya",
      "Satvy"
    ],
    [
      "Krpi",
      "Female",
      "not family",
      ""
    ],
    [
      "Vyas",
      "Male",
      "Satya",
      "Krpi"
    ],
    [
      "Atya",
      "Female",
      "Satya",
      ""
    ],
    [
      "Yodhan",
      "Male",
      "Dritha",
      ""
    ],
    [
      "Laki",
      "Male",
      "Jnki",
      ""
    ],
    [
      "Lavnya",
      "Female",
      "Jnki",
      ""
    ],
    [
      "Vasa",
      "Male",
      "Satvy",
      ""
    ],
    [
      "Kriya",
      "Male",
      "Krpi",
      ""
    ],
    [
      "Krithi",
      "Male",
      "Krpi",
      ""
    ]
  ]
}

